#!/usr/bin/env python3
"""
Build the static site in docs/ from the citation lookup database.

    python build_site.py                      # data/ -> docs/
    python build_site.py --records records.json   # also add repo links / unpublished tools

Inputs
  data/biotools_lookup.sqlite   the `tools` table made by `dochist-writer lookup build`
  data/overrides.json           hand-made citations (same file the CLI uses); they win
  --records records.json        OPTIONAL bio.tools dump (Zenodo snapshot). Adds homepage,
                                repository link, licence, description, and also recovers
                                tools the alias table lost to collisions or that have no paper.

Outputs (docs/, ready for GitHub Pages "deploy from branch /docs")
  index.html, app.js, lib.js, style.css, vendor/   copied from web/
  data/tools.json     one compact record per tool (search + citation fields)
  data/authors.json   {tool id: "Surname I.; ..."}, loaded only when a reference is exported
  data/meta.json      build date, counts, content hash (used to bust the browser cache)

The database is only read, never modified. Nothing here contacts the network.
"""
import argparse
import hashlib
import json
import re
import shutil
import sqlite3
import sys
import unicodedata
from datetime import date
from pathlib import Path

ROOT = Path(__file__).parent
PREPRINT_DOI_RE = re.compile(
    r"^10\.1101/(\d{4}\.\d{2}\.\d{2}\.\d+|\d{5,7})(v\d+)?$|^10\.7287/|^10\.21203/|^10\.20944/"
    r"|^10\.48550/", re.IGNORECASE)
REPO_HOSTS = re.compile(r"https?://(www\.)?(github\.com|gitlab\.[\w.]+|bitbucket\.org|"
                        r"sourceforge\.net/projects|git\.[\w.]+)/", re.IGNORECASE)


def normalize_alias(s):
    """Identical to dochist_writer.citations.normalize_alias (the JS copy must agree too)."""
    if not s:
        return ""
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "", s.lower().strip())


def clean(v):
    if v is None:
        return None
    if isinstance(v, str):
        v = v.strip()
        return v or None
    return v


def read_db(path):
    conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    cols = {r[1] for r in conn.execute("PRAGMA table_info(tools)")}
    extra = [c for c in ("corrected", "pubmed_filled", "crossref_filled", "api_added") if c in cols]
    rows = conn.execute(f"SELECT alias, biotools_id, display_name, doi, pmid, pmcid, title, "
                        f"journal, year, authors, bibtex_key, ambiguous, n_publications"
                        f"{''.join(', ' + c for c in extra)} FROM tools ORDER BY biotools_id, alias"
                        ).fetchall()
    conn.close()
    return rows


def build_tools(rows):
    """Group the one-row-per-alias table back into one tool per bio.tools ID."""
    tools = {}
    for r in rows:
        tid = r["biotools_id"]
        t = tools.get(tid)
        if t is None:
            t = tools[tid] = {
                "i": tid, "n": clean(r["display_name"]) or tid, "a": [],
                "d": clean(r["doi"]), "p": clean(r["pmid"]), "c": clean(r["pmcid"]),
                "t": clean(r["title"]), "j": clean(r["journal"]), "y": r["year"],
                "k": clean(r["bibtex_key"]), "np": r["n_publications"],
                "_authors": clean(r["authors"]), "f": [], "s": "biotools",
            }
            if r["ambiguous"]:
                t["f"].append("amb")
            if "corrected" in r.keys() and clean(r["corrected"]):
                t["f"].append("cor")
                t["note"] = "corrected: " + r["corrected"]
            filled = [x for x in ("pubmed_filled", "crossref_filled") if x in r.keys() and clean(r[x])]
            if filled:
                t["fill"] = "; ".join(f"{x.split('_')[0]}: {r[x]}" for x in filled)
        t["a"].append(r["alias"])
    return tools


def apply_overrides(tools, overrides):
    """Overrides win, as in citations.lookup(). Entries that share a display name and a
    DOI/URL (datasets / ncbidatasets) become one tool."""
    by_alias = {a: t for t in tools.values() for a in t["a"]}
    groups = {}
    for alias, o in overrides.items():
        groups.setdefault((o.get("display_name"), o.get("doi") or o.get("url")), []).append((alias, o))
    n_patched = n_new = 0
    for (name, _), members in groups.items():
        o = members[0][1]
        owners = {id(by_alias[a]): by_alias[a] for a, _ in members if a in by_alias}
        patch = {
            "d": clean(o.get("doi")), "p": clean(o.get("pmid")), "c": clean(o.get("pmcid")),
            "t": clean(o.get("title")), "j": clean(o.get("journal")), "y": o.get("year"),
            "k": o.get("bibtex_key") or f"{members[0][0]}{o.get('year', 'nd')}",
            "_authors": clean(o.get("authors")), "u": clean(o.get("url")), "s": "override",
        }
        if owners:
            targets, n_patched = list(owners.values()), n_patched + len(owners)
        else:
            tid = "override:" + members[0][0]
            t = {"i": tid, "n": name or members[0][0], "a": [], "np": 1, "f": [], "s": "override"}
            tools[tid] = t
            targets, n_new = [t], n_new + 1
        for t in targets:
            for stale in ("fill", "note"):  # provenance of the replaced database row
                t.pop(stale, None)
            t.update(patch)
            t["f"] = [x for x in t["f"] if x not in ("amb", "cor")]
            t["a"] = sorted(set(t["a"]) | {a for a, _ in members})
            if o.get("verify"):
                t["f"].append("verify")
            if name:
                t["n"] = name
            by_alias.update({a: t for a in t["a"]})
    return n_patched, n_new


def add_records(tools, records):
    """Attach homepage / repository / licence / description from a bio.tools dump, and add
    tools that have no row yet (no paper, or lost to an alias collision)."""
    n_added = n_repo = 0
    for rec in records:
        tid = rec.get("biotoolsID")
        if not tid:
            continue
        t = tools.get(tid)
        if t is None:
            t = tools[tid] = {"i": tid, "n": rec.get("name") or tid, "a": [], "f": ["nopub"],
                              "s": "biotools", "np": len(rec.get("publication") or [])}
            n_added += 1
        t["a"] = sorted(set(t["a"]) | {x for x in (normalize_alias(rec.get("name")),
                                                    normalize_alias(tid)) if x})
        home = clean(rec.get("homepage"))
        repo = None
        for link in rec.get("link") or []:
            if "Repository" in (link.get("type") or []) and clean(link.get("url")):
                repo = link["url"].strip()
                break
        repo = repo or (home if home and REPO_HOSTS.match(home) else None)
        if home:
            t["h"] = home
        if repo:
            t["r"] = repo
            n_repo += 1
        if clean(rec.get("license")):
            t["l"] = rec["license"]
        if clean(rec.get("description")):
            t["ds"] = re.sub(r"\s+", " ", rec["description"]).strip()[:240]
        topics = [x.get("term") for x in rec.get("topic") or [] if x.get("term")]
        if topics:
            t["tp"] = topics[:6]
    return n_added, n_repo


def finish(tools):
    """Derive flags, drop empty keys, and split authors out."""
    out, authors = [], {}
    for t in sorted(tools.values(), key=lambda x: (x["n"].lower(), x["i"])):
        if t.get("d") and PREPRINT_DOI_RE.match(t["d"]):
            t["f"].append("pre")
        if not t.get("d") and not t.get("p") and not t.get("u"):
            if "nopub" not in t["f"]:
                t["f"].append("nocite")
        if t.get("_authors"):
            authors[t["i"]] = t["_authors"]
        t.pop("_authors", None)
        t["a"] = [a for a in t["a"] if a != normalize_alias(t["n"])]  # name is searched anyway
        out.append({k: v for k, v in t.items() if v not in (None, "", [])})
    return out, authors


def sha256_of(path):
    """SHA-256 of a file, or of a folder's files (names + contents) in sorted order."""
    path = Path(path)
    h = hashlib.sha256()
    for f in sorted(path.rglob("*")) if path.is_dir() else [path]:
        if f.is_file():
            if path.is_dir():
                h.update(str(f.relative_to(path)).encode())
            h.update(f.read_bytes())
    return h.hexdigest()


def log_provenance(log, meta, inputs):
    """Append one JSON line per distinct build: what went in (hashes), what came out (version,
    counts). Rebuilding from identical inputs adds nothing, so the log is a change history."""
    entry = {
        "built": meta["built"], "version": meta["version"],
        "inputs": {k: sha256_of(v) for k, v in inputs.items() if v and Path(v).exists()},
        "counts": {k: v for k, v in meta.items() if k not in ("built", "version")},
    }
    lines = log.read_text(encoding="utf-8").splitlines() if log.exists() else []
    if lines:
        last = json.loads(lines[-1])
        if (last["version"], last["inputs"]) == (entry["version"], entry["inputs"]):
            return
        entry["previous_version"] = last["version"]
    with log.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(entry, ensure_ascii=False) + "\n")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--db", default=ROOT / "data" / "biotools_lookup.sqlite")
    ap.add_argument("--overrides", default=ROOT / "data" / "overrides.json")
    ap.add_argument("--records", help="bio.tools records.json (optional, see above)")
    ap.add_argument("--web", default=ROOT / "web", help="front-end sources to copy")
    ap.add_argument("--out", default=ROOT / "docs")
    ap.add_argument("--log", help="provenance log (default: PROVENANCE.jsonl next to the output folder)")
    args = ap.parse_args()

    db = Path(args.db)
    if not db.exists():
        sys.exit(f"ERROR: database not found: {db}")
    tools = build_tools(read_db(db))
    n_db = len(tools)

    overrides = {}
    if Path(args.overrides).exists():
        raw = json.loads(Path(args.overrides).read_text(encoding="utf-8"))
        raw.pop("_comment", None)
        overrides = {normalize_alias(k): v for k, v in raw.items()}
    n_patched, n_new = apply_overrides(tools, overrides)

    n_added = n_repo = 0
    if args.records:
        n_added, n_repo = add_records(tools, json.loads(Path(args.records).read_text(encoding="utf-8")))

    out_tools, authors = finish(tools)

    out = Path(args.out)
    (out / "data").mkdir(parents=True, exist_ok=True)
    dump = lambda o: json.dumps(o, ensure_ascii=False, separators=(",", ":"))
    tools_json, authors_json = dump(out_tools), dump(authors)
    version = hashlib.sha1((tools_json + authors_json).encode()).hexdigest()[:10]
    flags = lambda f: sum(f in t.get("f", []) for t in out_tools)
    meta = {
        "built": date.today().isoformat(), "version": version, "tools": len(out_tools),
        "with_doi": sum("d" in t for t in out_tools), "with_pmid": sum("p" in t for t in out_tools),
        "with_repo": sum("r" in t for t in out_tools), "ambiguous": flags("amb"),
        "preprint_only": flags("pre"), "corrected": flags("cor"), "verify": flags("verify"),
        "no_citation": flags("nocite") + flags("nopub"),
        "from_overrides": n_patched + n_new, "has_repo_links": bool(args.records),
    }
    (out / "data" / "tools.json").write_text(tools_json, encoding="utf-8")
    (out / "data" / "authors.json").write_text(authors_json, encoding="utf-8")
    (out / "data" / "meta.json").write_text(dump(meta), encoding="utf-8")

    web = Path(args.web)
    for f in web.rglob("*"):
        if f.is_file():
            dest = out / f.relative_to(web)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(f, dest)
    (out / ".nojekyll").write_text("")  # serve files as they are

    log_provenance(Path(args.log) if args.log else out.resolve().parent / "PROVENANCE.jsonl",
                   meta, {"database": db, "overrides": Path(args.overrides), "records": args.records,
                          "build_script": Path(__file__), "web": web})

    print(json.dumps(meta, indent=2))
    print(f"tools from database: {n_db}; overrides patched {n_patched} + added {n_new}; "
          f"records added {n_added}", file=sys.stderr)
    print(f"tools.json {len(tools_json) / 1e6:.1f} MB, authors.json {len(authors_json) / 1e6:.1f} MB "
          f"(served gzipped by GitHub Pages)", file=sys.stderr)


if __name__ == "__main__":
    main()

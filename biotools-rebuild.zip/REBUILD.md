# Rebuilding the site

Needs Python 3.8+ only (standard library). No network access, no GitHub Actions.

    python3 build_site.py        # or: make site
    make serve                   # preview at http://localhost:8000

Reads `data/biotools_lookup.sqlite` and `data/overrides.json`, copies `web/`, and writes `docs/`
(the folder GitHub Pages serves). Commit the new `docs/`.

To add repository links, licence and descriptions, and to recover tools with no paper:

    python3 build_site.py --records records.json

where `records.json` is a bio.tools registry dump (e.g. the Zenodo snapshot).

To change a citation by hand, edit `data/overrides.json` (key = lower-case alphanumeric tool name)
and rebuild. Entries with `"verify": true` show a "check: manual entry" badge on the site.
